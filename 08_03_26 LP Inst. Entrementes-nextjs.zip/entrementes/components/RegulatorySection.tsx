import { AlertTriangle, FileText, ShieldCheck } from 'lucide-react'
import { ReactNode } from 'react'

function Card({
  icon,
  title,
  text,
  highlight,
  accent = false,
}: {
  icon: ReactNode
  title: string
  text: string
  highlight: string
  accent?: boolean
}) {
  return (
    <div className="bg-[#F3F4F6]/40 p-7 md:p-10 rounded-3xl border border-gray-100 flex flex-col h-full hover:-translate-y-1 transition-all">
      <div
        className={`mb-6 bg-white w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm ${
          accent ? 'text-[#8B1E3F]' : 'text-[#1a202c]'
        }`}
      >
        {icon}
      </div>
      <h3 className="text-xl md:text-2xl font-bold mb-3 font-[family-name:var(--font-space)]">{title}</h3>
      <p className="text-gray-600 mb-6 flex-grow leading-relaxed">{text}</p>
      <div className="pt-4 border-t border-gray-200/50">
        <p className={`font-bold ${accent ? 'text-[#8B1E3F]' : 'text-[#1a202c]'}`}>{highlight}</p>
      </div>
    </div>
  )
}

export default function RegulatorySection() {
  return (
    <section className="bg-white py-16 md:py-32">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12 md:mb-24">
          <h2 className="text-2xl md:text-4xl lg:text-5xl font-bold text-gray-900 uppercase tracking-tighter font-[family-name:var(--font-space)]">
            Realidade Regulatória & Risco Financeiro
          </h2>
          <div className="w-16 md:w-24 h-1.5 bg-[#8B1E3F] mx-auto mt-6 rounded-full" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-10 max-w-7xl mx-auto">
          <Card
            icon={<AlertTriangle />}
            title="Multas Milionárias"
            text="Processos trabalhistas podem resultar em multas que ultrapassam seis dígitos."
            highlight="Risco civil e penal direto"
            accent
          />
          <Card
            icon={<FileText />}
            title="Passivo Trabalhista"
            text="A falta de provas da gestão de riscos é o principal passivo trabalhista moderno."
            highlight="Sua empresa está exposta?"
          />
          <Card
            icon={<ShieldCheck />}
            title="Reputação em Risco"
            text="Casos de burnout e assédio afetam diretamente o valor da marca e talentos."
            highlight="Proteja seu maior ativo"
          />
        </div>
      </div>
    </section>
  )
}
