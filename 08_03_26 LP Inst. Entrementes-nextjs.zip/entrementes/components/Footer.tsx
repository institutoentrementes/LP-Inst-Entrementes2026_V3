import { Linkedin, Instagram } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-[#1a202c] py-12 text-center border-t border-white/10">
      <div className="container mx-auto px-4 space-y-4">
        <p className="text-sm text-white font-medium">
          © {new Date().getFullYear()} Instituto Entrementes. Todos os direitos reservados.
        </p>
        <p className="text-xs text-gray-400">
          CNPJ: 48.319.338/0001-37 | Belo Horizonte - MG
        </p>
        <p className="text-xs text-gray-400">
          Responsável Técnico: Leonardo Lanna - CRP 04/60663
        </p>
        <div className="flex justify-center gap-6 pt-4">
          <a
            href="https://www.linkedin.com/in/leolannapsi/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
            className="text-gray-400 hover:text-[#8B1E3F] transition-colors"
          >
            <Linkedin className="w-6 h-6" />
          </a>
          <a
            href="https://www.instagram.com/leolanna.psi/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
            className="text-gray-400 hover:text-[#8B1E3F] transition-colors"
          >
            <Instagram className="w-6 h-6" />
          </a>
        </div>
      </div>
    </footer>
  )
}
