import { MessageCircle } from 'lucide-react'

const WHATSAPP_NUMBER = '5531998900757'
const getWhatsappLink = (msg: string) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`

export default function CTASection() {
  return (
    <section className="bg-[#F3F4F6]/20 py-20 md:py-32 text-center">
      <div className="container mx-auto px-6 max-w-4xl">
        <h2 className="text-3xl md:text-5xl font-bold text-[#1a202c] mb-6 font-[family-name:var(--font-space)]">
          Conformidade não se declara. Se comprova.
        </h2>
        <p className="text-lg md:text-2xl text-gray-600 mb-10">
          Agende seu Diagnóstico Estratégico agora mesmo e blinde sua empresa.
        </p>
        <a
          href={getWhatsappLink('Olá, gostaria de agendar um Diagnóstico Estratégico.')}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-4 bg-[#8B1E3F] hover:bg-[#a6264d] text-white font-bold py-5 px-10 md:px-14 rounded-2xl text-lg md:text-xl shadow-xl transition-all transform hover:scale-105 active:scale-95"
        >
          Falar com nossa equipe
          <MessageCircle className="w-6 h-6" />
        </a>
      </div>
    </section>
  )
}
