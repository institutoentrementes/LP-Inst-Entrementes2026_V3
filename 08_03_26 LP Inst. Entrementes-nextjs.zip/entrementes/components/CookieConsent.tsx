'use client'

import { useState, useEffect } from 'react'
import { Shield, X } from 'lucide-react'

function CookieOption({
  title,
  desc,
  checked,
  onChange,
  disabled,
}: {
  title: string
  desc: string
  checked: boolean
  onChange?: (v: boolean) => void
  disabled?: boolean
}) {
  return (
    <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5">
      <div className="flex-grow">
        <h5 className="text-white font-bold text-sm mb-1">{title}</h5>
        <p className="text-gray-500 text-xs">{desc}</p>
      </div>
      <button
        disabled={disabled}
        onClick={() => onChange && onChange(!checked)}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
          checked ? 'bg-[#8B1E3F]' : 'bg-gray-700'
        } ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
      >
        <span
          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
            checked ? 'translate-x-6' : 'translate-x-1'
          }`}
        />
      </button>
    </div>
  )
}

export default function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [prefs, setPrefs] = useState({ analytics: true, marketing: false })

  useEffect(() => {
    const consent = localStorage.getItem('cookie-consent')
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1500)
      return () => clearTimeout(timer)
    }
  }, [])

  const saveConsent = (data: typeof prefs) => {
    localStorage.setItem('cookie-consent', JSON.stringify({ ...data, date: new Date().toISOString() }))
    setIsVisible(false)
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-0 left-0 w-full z-[100] p-4 md:p-6 animate-in slide-in-from-bottom">
      <div className="container mx-auto max-w-4xl bg-[#111827] border border-white/10 rounded-2xl shadow-2xl overflow-hidden">
        {!showSettings ? (
          <div className="p-5 md:p-8 flex flex-col md:flex-row items-center gap-6">
            <div className="bg-[#8B1E3F]/20 p-3 rounded-xl hidden md:block">
              <Shield className="w-8 h-8 text-[#a6264d]" />
            </div>
            <div className="flex-grow text-center md:text-left">
              <h4 className="text-white font-bold text-lg mb-2 font-[family-name:var(--font-space)]">
                Privacidade e Cookies
              </h4>
              <p className="text-gray-400 text-sm leading-relaxed">
                Utilizamos cookies para melhorar sua experiência. Ao clicar em &quot;Aceitar Todos&quot;,
                você concorda com o uso de cookies conforme nossa Política de Privacidade.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
              <button
                onClick={() => setShowSettings(true)}
                className="px-6 py-3 text-sm font-bold text-white/70 border border-white/10 rounded-xl hover:bg-white/5 transition-colors"
              >
                Configurações
              </button>
              <button
                onClick={() => saveConsent({ analytics: true, marketing: true })}
                className="px-8 py-3 text-sm font-bold text-white bg-[#8B1E3F] hover:bg-[#a6264d] rounded-xl shadow-lg transition-all active:scale-95"
              >
                Aceitar Todos
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6 md:p-8">
            <div className="flex justify-between items-center mb-6">
              <h4 className="text-white font-bold text-xl font-[family-name:var(--font-space)]">
                Preferências de Cookies
              </h4>
              <button onClick={() => setShowSettings(false)} className="text-gray-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="space-y-4 mb-8">
              <CookieOption title="Essenciais" desc="Necessários para o funcionamento do site." checked disabled />
              <CookieOption
                title="Analíticos"
                desc="Nos ajudam a entender o tráfego do site."
                checked={prefs.analytics}
                onChange={(v) => setPrefs({ ...prefs, analytics: v })}
              />
              <CookieOption
                title="Marketing"
                desc="Utilizados para anúncios relevantes."
                checked={prefs.marketing}
                onChange={(v) => setPrefs({ ...prefs, marketing: v })}
              />
            </div>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowSettings(false)}
                className="px-6 py-3 text-sm font-bold text-white/70"
              >
                Voltar
              </button>
              <button
                onClick={() => saveConsent(prefs)}
                className="px-8 py-3 text-sm font-bold text-white bg-[#8B1E3F] hover:bg-[#a6264d] rounded-xl shadow-lg"
              >
                Salvar Preferências
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
