import { BarChart3, Cpu, Medal } from 'lucide-react'
import { ReactNode } from 'react'

function SolutionItem({ icon, title, text }: { icon: ReactNode; title: string; text: string }) {
  return (
    <div className="flex flex-col sm:flex-row gap-5 items-start">
      <div className="text-[#8B1E3F] bg-white p-4 rounded-2xl shadow-md shrink-0">{icon}</div>
      <div>
        <h3 className="text-xl font-bold text-gray-900 mb-2 font-[family-name:var(--font-space)]">{title}</h3>
        <p className="text-gray-700 text-lg leading-relaxed">{text}</p>
      </div>
    </div>
  )
}

export default function SolutionSection() {
  return (
    <section className="relative py-20 md:py-32 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=1920"
          alt="Tecnologia e análise de dados"
          className="w-full h-full object-cover"
        />
        <div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(to bottom, rgba(243,244,246,0.85), rgba(243,244,246,0.95))',
          }}
        />
        <div className="absolute inset-0 bg-tech-pattern opacity-30" />
      </div>

      <div className="container mx-auto px-4 relative z-10 max-w-6xl">
        <h2 className="text-center text-3xl md:text-4xl font-bold text-gray-900 uppercase font-[family-name:var(--font-space)] mb-16">
          Nossa Solução Comprovada
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 mb-16">
          <SolutionItem
            icon={<BarChart3 />}
            title="Arquitetura de Blindagem Quantificada™"
            text="Metodologia exclusiva para estruturar, mensurar e documentar a gestão de riscos psicossociais."
          />
          <SolutionItem
            icon={<Cpu />}
            title="Sistema QRP™ (Quantificação de Risco)"
            text="Método que gera evidências integradas entre setores, transformando dados em provas quantificáveis."
          />
        </div>

        <div className="bg-[#111827] rounded-3xl p-7 md:p-12 flex flex-col md:flex-row items-center gap-6 shadow-2xl border border-white/10">
          <div className="text-white bg-[#8B1E3F] p-4 rounded-full shadow-inner shrink-0">
            <Medal className="w-10 h-10 md:w-16 md:h-16" />
          </div>
          <div className="text-center md:text-left">
            <h4 className="text-white font-bold text-xl md:text-2xl mb-3 uppercase tracking-wide font-[family-name:var(--font-space)]">
              Garantia de Lastro Probatório Blindado™
            </h4>
            <p className="text-gray-300 text-lg">
              Garantimos a solidez das provas documentais em qualquer fiscalização trabalhista sobre NR-01.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
