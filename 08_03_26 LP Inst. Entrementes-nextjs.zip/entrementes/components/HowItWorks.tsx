const steps = [
  {
    number: '01',
    title: 'Diagnóstico Estratégico',
    description:
      'Avaliação técnica e confidencial do nível atual de conformidade da sua empresa com a NR-01. Identificamos lacunas, riscos expostos e prioridades de ação.',
    duration: 'Até 48h para retorno',
  },
  {
    number: '02',
    title: 'Mapeamento de Riscos QRP™',
    description:
      'Aplicação do Sistema QRP™ (Quantificação de Risco Psicossocial) para mensurar e documentar os fatores de risco de forma integrada entre setores.',
    duration: '2 a 4 semanas',
  },
  {
    number: '03',
    title: 'Arquitetura de Blindagem',
    description:
      'Estruturação do dossiê probatório com evidências quantificáveis, protocolos documentais e plano de ação aprovado pela equipe técnica.',
    duration: '4 a 8 semanas',
  },
  {
    number: '04',
    title: 'Lastro Probatório Blindado™',
    description:
      'Entrega do conjunto de provas documentais sólidas, prontas para qualquer fiscalização trabalhista. Suporte contínuo para atualizações e auditorias.',
    duration: 'Suporte contínuo',
  },
]

export default function HowItWorks() {
  return (
    <section id="como-funciona" className="bg-[#111827] py-20 md:py-32">
      <div className="container mx-auto px-6 max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-2xl md:text-4xl lg:text-5xl font-bold text-white uppercase tracking-tighter font-[family-name:var(--font-space)]">
            Como Funciona
          </h2>
          <div className="w-16 md:w-24 h-1.5 bg-[#8B1E3F] mx-auto mt-6 rounded-full" />
          <p className="text-gray-400 mt-6 text-lg max-w-2xl mx-auto">
            Do diagnóstico ao lastro probatório completo — um processo estruturado para proteger sua empresa.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {steps.map((step, i) => (
            <div
              key={i}
              className="relative bg-white/5 border border-white/10 rounded-3xl p-8 hover:border-[#8B1E3F]/50 transition-all group"
            >
              <div className="flex items-start gap-6">
                <span className="text-5xl font-black text-[#8B1E3F]/30 font-[family-name:var(--font-space)] group-hover:text-[#8B1E3F]/60 transition-colors leading-none select-none">
                  {step.number}
                </span>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-white mb-3 font-[family-name:var(--font-space)]">
                    {step.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed mb-4">{step.description}</p>
                  <span className="inline-block text-xs font-bold uppercase tracking-widest text-[#a6264d] bg-[#8B1E3F]/10 border border-[#8B1E3F]/20 rounded-full px-3 py-1">
                    {step.duration}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
