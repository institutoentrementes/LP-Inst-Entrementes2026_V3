'use client'

import { Shield } from 'lucide-react'

const WHATSAPP_NUMBER = '5531998900757'
const getWhatsappLink = (msg: string) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`

export default function Navbar() {
  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-[#1a202c]/95 backdrop-blur-md border-b border-white/5 py-3 md:py-4">
      <div className="container mx-auto px-5 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="bg-[#8B1E3F] p-1.5 rounded-lg shadow-lg">
            <Shield className="w-5 h-5 md:w-6 md:h-6 text-white" />
          </div>
          <div className="flex flex-col items-start leading-none">
            <span className="text-[8px] md:text-[10px] uppercase tracking-[0.3em] text-white/60 mb-0.5 font-semibold">
              Instituto
            </span>
            <span className="text-base md:text-xl font-bold tracking-tighter text-white uppercase font-[family-name:var(--font-space)]">
              Entrementes
            </span>
          </div>
        </div>
        <a
          href={getWhatsappLink('Olá, gostaria de falar com a equipe do Instituto Entrementes.')}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-[#8B1E3F] hover:bg-[#a6264d] text-white text-xs md:text-sm font-bold py-2.5 px-5 md:px-6 rounded-full transition-all shadow-lg active:scale-95"
        >
          Falar com nossa equipe
        </a>
      </div>
    </nav>
  )
}
