import { Quote } from 'lucide-react'

const testimonials = [
  {
    quote:
      'O Instituto Entrementes nos ajudou a estruturar toda a documentação antes da fiscalização. Saímos sem nenhuma autuação e com um plano sólido de gestão.',
    name: 'Diretora de RH',
    company: 'Empresa do setor de saúde · MG',
    initials: 'DR',
  },
  {
    quote:
      'Antes do trabalho com o Leonardo, não tínhamos nenhuma evidência formal de gestão de riscos psicossociais. Hoje temos um dossiê completo e auditável.',
    name: 'Gerente Jurídico',
    company: 'Indústria de manufatura · SP',
    initials: 'GJ',
  },
  {
    quote:
      'A metodologia QRP™ foi decisiva para transformar dados internos em provas concretas. Recomendo a qualquer empresa que queira sair do risco para a conformidade.',
    name: 'CEO',
    company: 'Empresa de tecnologia · BH',
    initials: 'CE',
  },
]

const stats = [
  { value: '80+', label: 'Empresas atendidas' },
  { value: '100%', label: 'Taxa de conformidade nas fiscalizações' },
  { value: 'R$0', label: 'Em autuações após a blindagem' },
  { value: '48h', label: 'Para retorno do diagnóstico' },
]

export default function Testimonials() {
  return (
    <section className="bg-white py-20 md:py-32">
      <div className="container mx-auto px-6 max-w-7xl">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
          {stats.map((s, i) => (
            <div key={i} className="text-center p-6 bg-[#F3F4F6]/60 rounded-2xl border border-gray-100">
              <div className="text-3xl md:text-5xl font-black text-[#8B1E3F] font-[family-name:var(--font-space)] mb-2">
                {s.value}
              </div>
              <div className="text-sm text-gray-600 font-medium leading-snug">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Heading */}
        <div className="text-center mb-14">
          <h2 className="text-2xl md:text-4xl lg:text-5xl font-bold text-gray-900 uppercase tracking-tighter font-[family-name:var(--font-space)]">
            O que nossos clientes dizem
          </h2>
          <div className="w-16 md:w-24 h-1.5 bg-[#8B1E3F] mx-auto mt-6 rounded-full" />
        </div>

        {/* Testimonials grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="bg-[#F3F4F6]/40 border border-gray-100 rounded-3xl p-8 flex flex-col gap-6 hover:-translate-y-1 transition-all"
            >
              <Quote className="w-8 h-8 text-[#8B1E3F]/40" />
              <p className="text-gray-700 leading-relaxed flex-grow italic">"{t.quote}"</p>
              <div className="flex items-center gap-4 pt-4 border-t border-gray-200/50">
                <div className="w-11 h-11 rounded-full bg-[#8B1E3F] flex items-center justify-center text-white font-bold text-sm shrink-0">
                  {t.initials}
                </div>
                <div>
                  <p className="font-bold text-gray-900 text-sm">{t.name}</p>
                  <p className="text-xs text-gray-500">{t.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
