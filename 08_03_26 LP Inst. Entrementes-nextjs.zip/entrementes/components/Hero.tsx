'use client'

import { Lock, ChevronDown } from 'lucide-react'

const WHATSAPP_NUMBER = '5531998900757'
const getWhatsappLink = (msg: string) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`

export default function Hero() {
  return (
    <header className="relative min-h-[90vh] md:min-h-screen flex items-center overflow-hidden pt-20">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1920"
          alt="Ambiente corporativo"
          className="w-full h-full object-cover"
        />
        <div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(to bottom, rgba(26,32,44,0.92), rgba(17,24,39,0.98))',
          }}
        />
      </div>

      <div className="container mx-auto px-6 py-16 md:py-24 relative z-10 flex flex-col items-center">
        {/* Badge */}
        <div className="mb-6 inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-2 text-xs font-bold uppercase tracking-widest text-white/80">
          <span className="w-2 h-2 bg-[#8B1E3F] rounded-full animate-pulse" />
          NR-01 em vigor — sua empresa está preparada?
        </div>

        <div className="max-w-4xl text-center space-y-6 md:space-y-10 mb-12">
          <h1 className="text-3xl md:text-6xl lg:text-7xl font-bold leading-[1.25] md:leading-[1.2] text-white font-[family-name:var(--font-space)] tracking-tight pb-2">
            Sua empresa conseguiria se defender hoje de uma fiscalização sobre riscos psicossociais?
          </h1>
          <p className="text-base md:text-2xl text-white/80 font-light max-w-3xl mx-auto leading-relaxed">
            A NR-01 exige provas documentais e evidências robustas de gestão de riscos psicossociais.
            Evite multas e processos trabalhistas milionários com nossa{' '}
            <span className="text-white font-semibold">Arquitetura de Blindagem Quantificada™</span>.
          </p>

          {/* CTAs */}
          <div className="pt-6 md:pt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href={getWhatsappLink('Olá, gostaria de solicitar um Diagnóstico Estratégico.')}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto bg-[#8B1E3F] hover:bg-[#a6264d] transition-all transform hover:scale-105 text-white font-bold py-4 md:py-5 px-8 md:px-12 rounded-xl text-lg md:text-xl shadow-2xl flex justify-center items-center gap-3"
            >
              <Lock className="w-5 h-5 md:w-6 md:h-6" />
              Solicitar Diagnóstico Estratégico
            </a>

            {/* Secondary CTA — NEW */}
            <a
              href="#como-funciona"
              className="w-full sm:w-auto bg-white/10 hover:bg-white/20 border border-white/20 transition-all text-white font-bold py-4 md:py-5 px-8 md:px-10 rounded-xl text-lg md:text-xl flex justify-center items-center gap-2"
            >
              Ver como funciona
              <ChevronDown className="w-5 h-5" />
            </a>
          </div>

          <div className="flex flex-col items-center gap-1">
            <span className="text-[10px] md:text-xs text-white/70 font-bold tracking-[0.2em] uppercase">
              Avaliação técnica confidencial
            </span>
            <span className="text-[10px] md:text-xs text-[#a6264d] font-bold tracking-[0.2em] uppercase">
              Resposta em até 48h
            </span>
          </div>
        </div>
      </div>
    </header>
  )
}
