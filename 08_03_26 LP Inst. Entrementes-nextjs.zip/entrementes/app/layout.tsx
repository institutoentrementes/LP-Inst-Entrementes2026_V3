import type { Metadata } from 'next'
import { Inter, Space_Grotesk } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const spaceGrotesk = Space_Grotesk({ subsets: ['latin'], variable: '--font-space' })

export const metadata: Metadata = {
  title: 'Instituto Entrementes | Blindagem Psicossocial & NR-01',
  description:
    'A NR-01 exige provas documentais robustas. Evite multas milionárias e processos trabalhistas com nossa Arquitetura de Blindagem Quantificada™. Diagnóstico estratégico para sua empresa.',
  keywords: [
    'NR-01', 'riscos psicossociais', 'blindagem trabalhista',
    'psicologia organizacional', 'compliance trabalhista', 'burnout empresarial',
    'passivo trabalhista', 'Instituto Entrementes', 'Leonardo Lanna'
  ],
  authors: [{ name: 'Instituto Entrementes' }],
  robots: 'index, follow',
  openGraph: {
    type: 'website',
    locale: 'pt_BR',
    url: 'https://institutoentrementes.com.br',
    title: 'Instituto Entrementes | Blindagem Psicossocial & NR-01',
    description:
      'Evite multas milionárias com a Arquitetura de Blindagem Quantificada™. Gestão de riscos psicossociais com lastro probatório para NR-01.',
    siteName: 'Instituto Entrementes',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Instituto Entrementes – Blindagem Psicossocial',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Instituto Entrementes | Blindagem Psicossocial & NR-01',
    description: 'Evite multas milionárias com gestão de riscos psicossociais documentada.',
    images: ['/og-image.jpg'],
  },
  metadataBase: new URL('https://institutoentrementes.com.br'),
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="font-sans antialiased text-gray-900 bg-white">
        {children}
      </body>
    </html>
  )
}
