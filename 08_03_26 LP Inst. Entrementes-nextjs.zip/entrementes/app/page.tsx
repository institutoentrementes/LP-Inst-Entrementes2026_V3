import Navbar from '@/components/Navbar'
import Hero from '@/components/Hero'
import RegulatorySection from '@/components/RegulatorySection'
import HowItWorks from '@/components/HowItWorks'
import SolutionSection from '@/components/SolutionSection'
import Testimonials from '@/components/Testimonials'
import CTASection from '@/components/CTASection'
import Footer from '@/components/Footer'
import WhatsAppButton from '@/components/WhatsAppButton'
import CookieConsent from '@/components/CookieConsent'

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <Hero />
      <RegulatorySection />
      <HowItWorks />
      <SolutionSection />
      <Testimonials />
      <CTASection />
      <Footer />
      <WhatsAppButton />
      <CookieConsent />
    </main>
  )
}
